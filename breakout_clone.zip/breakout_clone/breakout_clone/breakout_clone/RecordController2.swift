//
//  RecordController2.swift
//  breakout_clone
//
//  Created by User14 on 2019/1/20.
//  Copyright © 2019 com. All rights reserved.
//

import UIKit
import Foundation

class RecordController2: UITableViewController {
    
    //@IBOutlet var rank2: [UILabel]!
    //@IBOutlet var rank3: [UILabel]!
    
    
    @IBOutlet var nameRank2: [UILabel]!
    @IBOutlet var scoreRank2: [UILabel]!
    @IBOutlet var dateRank2: [UILabel]!
    
    //var record:[Record] = [Record(name: "aaa", score: "300", date: "12/17")]
    var record2:[Record2] = [Record2]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let record2 = Record2.readFromFile() {
            self.record2 = record2
            self.record2.sort(by: { (Int($0.score)! > Int($1.score)!) })
            
            //print(self.record2[0].name)
            //print(self.record2[0].score)
            //print(self.record2[0].date)
            
            for i in 0...2{
                if(self.record2.count>i){
                    nameRank2[i].text = self.record2[i].name
                    scoreRank2[i].text = self.record2[i].score
                    dateRank2[i].text = self.record2[i].date
                }
                else{
                    nameRank2[i].text = " "
                    scoreRank2[i].text = " "
                    dateRank2[i].text = " "
                }
            }
        }
    }
    
    
    struct Record2: Codable  {
        var name: String
        var score: String
        var date: String
        
        
        static let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        
        static func readFromFile() -> [Record2]? {
            let propertyDecoder = PropertyListDecoder()
            let url = Record2.documentsDirectory.appendingPathComponent("record2")
            if let data = try? Data(contentsOf: url), let record2 = try? propertyDecoder.decode([Record2].self, from: data) {
                return record2
            }
            else {
                return nil
            }
            
        }
        
        static func saveToFile(record2: [Record2]) {
            let propertyEncoder = PropertyListEncoder()
            if let data = try? propertyEncoder.encode(record2) {
                let url = Record2.documentsDirectory.appendingPathComponent("record2")
                try? data.write(to: url)
            }
            
        }
    }
    
    
    //override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    // #warning Incomplete implementation, return the number of rows
    //   return record.count
    //}
    
    
    //override func tableView(_ tableView: UITableView, cellForRowAt //indexPath: IndexPath) -> UITableViewCell {
    //  let cell = tableView.dequeueReusableCell(withIdentifier: "recordCell", for: indexPath) as! RecordTableViewCell
    //  let rowRecord = record[indexPath.row]
    //   cell.nameLabel?.text = rowRecord.name
    //   cell.scoreLabel?.text = rowRecord.score
    //   cell.dateLabel?.text = rowRecord.date
    //
    //   return cell
    //}
    
}


