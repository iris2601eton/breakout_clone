//
//  RecordController.swift
//  breakout_clone
//
//  Created by User14 on 2019/1/15.
//  Copyright © 2019 com. All rights reserved.
//

import UIKit
import Foundation

class RecordController: UITableViewController {
    
    //@IBOutlet var rank2: [UILabel]!
    //@IBOutlet var rank3: [UILabel]!


    @IBOutlet var nameRank: [UILabel]!
    @IBOutlet var scoreRank: [UILabel]!
    @IBOutlet var dateRank: [UILabel]!
    
    //var record:[Record] = [Record(name: "aaa", score: "300", date: "12/17")]
    var record:[Record] = [Record]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let record = Record.readFromFile() {
            self.record = record
            self.record.sort(by: { (Int($0.score)! > Int($1.score)!) })

            //print(self.record[0].name)
            //print(self.record[0].score)
            //print(self.record[0].date)
            
            for i in 0...2{
                if(self.record.count>i){
                    nameRank[i].text = self.record[i].name
                    scoreRank[i].text = self.record[i].score
                    dateRank[i].text = self.record[i].date
                }
                else{
                    nameRank[i].text = " "
                    scoreRank[i].text = " "
                    dateRank[i].text = " "
                }
            }
        }
    }

    
    struct Record: Codable  {
        var name: String
        var score: String
        var date: String
        
        
        static let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        
        static func readFromFile() -> [Record]? {
            let propertyDecoder = PropertyListDecoder()
            let url = Record.documentsDirectory.appendingPathComponent("record")
            if let data = try? Data(contentsOf: url), let record = try? propertyDecoder.decode([Record].self, from: data) {
                return record
            }
            else {
                return nil
            }
            
        }

        static func saveToFile(record: [Record]) {
            let propertyEncoder = PropertyListEncoder()
            if let data = try? propertyEncoder.encode(record) {
                let url = Record.documentsDirectory.appendingPathComponent("record")
                try? data.write(to: url)
            }
            
        }
    }

    
    //override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
     //   return record.count
    //}
    
    
    //override func tableView(_ tableView: UITableView, cellForRowAt //indexPath: IndexPath) -> UITableViewCell {
      //  let cell = tableView.dequeueReusableCell(withIdentifier: "recordCell", for: indexPath) as! RecordTableViewCell
     //  let rowRecord = record[indexPath.row]
     //   cell.nameLabel?.text = rowRecord.name
     //   cell.scoreLabel?.text = rowRecord.score
     //   cell.dateLabel?.text = rowRecord.date
    //
     //   return cell
    //}

}


