//
//  TimeController.swift
//  breakout_clone
//
//  Created by User14 on 2019/1/20.
//  Copyright © 2019 com. All rights reserved.
//

import UIKit
import AVFoundation

class TimeController: UIViewController {
    @IBOutlet weak var line: UIImageView!
    @IBOutlet weak var touch: UIImageView!
    @IBOutlet weak var start: UIButton!
    @IBOutlet weak var back: UIButton!
    @IBOutlet weak var ball: UIImageView!
    @IBOutlet weak var playView: UIView!
    @IBOutlet weak var showScore: UILabel!
    @IBOutlet weak var light: UIImageView!
    @IBOutlet weak var touchView: UIView!
    @IBOutlet weak var winView: UIView!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var winName: UITextField!
    @IBOutlet weak var winSend: UIButton!
    

    
    var width:Int = 0
    var height:Int = 0
    var score:Int = 0
    var moveX:Double = 0
    var moveY:Double = 0
    var prX:CGFloat = 0
    var PowerStorage:Double = 1
    var dX:Double = 0
    var dY:Double = 0
    var time = 60
    var angel:Double = 0
    var lineWidth:Int = 100
    var isPlaying:Bool = false
    var powerSet:Bool = false
    var brickView:UIView!
    var timer1:Timer!
    var timer2:Timer!
    var timer3:Timer!
    var brickImageView:[UIImageView] = []
    var HitPlayer :AVAudioPlayer!
    var GameOverPlayer :AVAudioPlayer!
    var PowerupPlayer :AVAudioPlayer!
    var WinPlayer :AVAudioPlayer!
    var CatchPlayer0 :AVAudioPlayer!
    var CatchPlayer1 :AVAudioPlayer!
    var CatchPlayer2 :AVAudioPlayer!
    var firstPoint:CGPoint = CGPoint(x:0,y:0)
    var secondPoint:CGPoint = CGPoint(x:0,y:0)
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        //print(touches.first)
        let first = (touches as NSSet).allObjects[0] as! UITouch
        firstPoint = first.location(in: self.view)
        secondPoint = first.location(in: self.touchView)
        if(abs(firstPoint.x-prX)>0 && isPlaying){
            if(PowerStorage<3){
                PowerStorage += 0.03
                if(light.alpha < 0.8){
                    light.alpha = CGFloat((PowerStorage-1)/2.2)
                }
            }
        }
        prX = line.center.x
        light.center = secondPoint
        firstPoint.y = line.center.y
        line.center = firstPoint
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        PowerStorage = 1
        light.alpha = 0
    }
    
    
    
    @IBAction func GameStart(_ sender: Any) {
        // 建立播放器
        let soundPath1 = Bundle.main.path(
            forResource: "button03a", ofType: "mp3")
        do {
            HitPlayer = try AVAudioPlayer(
                contentsOf: NSURL.fileURL(withPath: soundPath1!))
            HitPlayer.numberOfLoops = 0
            HitPlayer.prepareToPlay()
        } catch {
            print("error")
        }
        
        
        let soundPath2 = Bundle.main.path(
            forResource: "powerup01", ofType: "mp3")
        do {
            PowerupPlayer = try AVAudioPlayer(
                contentsOf: NSURL.fileURL(withPath: soundPath2!))
            PowerupPlayer.numberOfLoops = 0
            PowerupPlayer.prepareToPlay()
        } catch {
            print("error")
        }
        
        let soundPath3 = Bundle.main.path(
            forResource: "attack0", ofType: "mp3")
        do {
            CatchPlayer0 = try AVAudioPlayer(
                contentsOf: NSURL.fileURL(withPath: soundPath3!))
            CatchPlayer0.numberOfLoops = 0
            CatchPlayer0.prepareToPlay()
        } catch {
            print("error")
        }
        
        let soundPath4 = Bundle.main.path(
            forResource: "attack1", ofType: "mp3")
        do {
            CatchPlayer1 = try AVAudioPlayer(
                contentsOf: NSURL.fileURL(withPath: soundPath4!))
            CatchPlayer1.numberOfLoops = 0
            CatchPlayer1.prepareToPlay()
        } catch {
            print("error")
        }
        
        let soundPath5 = Bundle.main.path(
            forResource: "attack2", ofType: "mp3")
        do {
            CatchPlayer2 = try AVAudioPlayer(
                contentsOf: NSURL.fileURL(withPath: soundPath5!))
            CatchPlayer2.numberOfLoops = 0
            CatchPlayer2.prepareToPlay()
        } catch {
            print("error")
        }
        
        
        width = Int(playView.frame.width)
        height = Int(playView.frame.height)
        score = 0
        time = 60
        light.alpha = 0
        self.showScore.text = String(format: "分數:%d   時間:%d",0,60)
        PowerStorage = 1
        brickImageView = []
        //brickUIView = []
        brickView = UIView(frame: CGRect(x: 0, y: 0, width: width*5/6, height: height*3/5))
        brickView.center = CGPoint(x: width/2,y: height*2/5)
        //brickView.backgroundColor = UIColor.yellow
        self.view.addSubview(brickView)
        bornBrick()
        bornBrick()
        bornBrick()
        bornBrick()
        bornBrick()
        start.isHidden = true
        back.isHidden = true
        line.isHidden = false
        ball.isHidden = false
        winView.isHidden = true
        isPlaying = true
        self.ball.center.x = self.playView.center.x
        self.ball.center.y = (UIScreen.main.bounds.height*6.5/10)-25
        self.line.center.x = self.playView.center.x
        self.line.center.y = (UIScreen.main.bounds.height*6.5/10)
        moveX = 1
        moveY = 1.5
    }
    
    func GameOver() {
        let soundPath6 = Bundle.main.path(
            forResource: "select08", ofType: "mp3")
        do {
            GameOverPlayer = try AVAudioPlayer(
                contentsOf: NSURL.fileURL(withPath: soundPath6!))
            GameOverPlayer.numberOfLoops = 0
            GameOverPlayer.prepareToPlay()
        } catch {
            print("error")
        }
        start.isHidden = false
        back.isHidden = false
        isPlaying = false
        line.isHidden = true
        ball.isHidden = true
        moveX = 0
        moveY = 0
        PowerStorage = 1
        light.alpha = 0
        brickView.removeFromSuperview()
        timer1 = nil
        timer2 = nil
        timer3 = nil
        self.GameOverPlayer.play()
    }
    
    func Win() {
        let soundPath7 = Bundle.main.path(
            forResource: "win", ofType: "mp3")
        do {
            WinPlayer = try AVAudioPlayer(
                contentsOf: NSURL.fileURL(withPath: soundPath7!))
            WinPlayer.numberOfLoops = 0
            WinPlayer.prepareToPlay()
        } catch {
            print("error")
        }
        self.WinPlayer.play()
        scoreLabel.text = String(format: "分數:%d",self.score)
        start.isHidden = false
        back.isHidden = false
        line.isHidden = true
        ball.isHidden = true
        self.winView.isHidden = false
        isPlaying = false
        moveX = 0
        moveY = 0
        PowerStorage = 1
        light.alpha = 0
        brickView.removeFromSuperview()
        timer1 = nil
        timer2 = nil
        timer3 = nil
        self.WinPlayer.play()
    }
    
    @IBAction func ScoreSend(_ sender: UIButton) {
        let now:Date = Date()
        let dateFormat:DateFormatter = DateFormatter()
        dateFormat.dateFormat = "yyyy/MM/dd HH:mm:ss"
        let dateString:String = dateFormat.string(from: now)
        
        winView.isHidden = true
        let save2:RecordController2.Record2 = RecordController2.Record2(name: winName.text!, score:String(format: "%d",score), date: dateString)
        var SaveRecord2:[RecordController2.Record2] = []
        if let record2 = RecordController2.Record2.readFromFile() {
            SaveRecord2 = record2
        }
        SaveRecord2.append(save2)
        RecordController2.Record2.saveToFile(record2: SaveRecord2)
        //print(SaveRecord[SaveRecord.count-1].name)
        //print(SaveRecord[SaveRecord.count-1].score)
        //print(SaveRecord[SaveRecord.count-1].date)
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        // 結束編輯 把鍵盤隱藏起來
        self.view.endEditing(true)
        return true
    }
    
    
    func startTimer1() {
        self.timer1 = Timer.scheduledTimer(withTimeInterval: 0.005, repeats: true) { (_) in
            if(self.isPlaying){
                if(self.light.alpha>0.2){
                    self.PowerupPlayer.play()
                }
                if(self.moveX>1.2 || self.moveY>1.2){
                    self.moveX /= 1.003
                    self.moveY /= 1.003
                }
                if(abs(self.line.center.x-self.prX)==0){
                    if(self.PowerStorage>1){
                        self.PowerStorage -= 0.005
                        self.light.alpha = CGFloat((self.PowerStorage-1)/2.2)
                    }
                    else{
                        self.PowerStorage = 1
                        self.light.alpha = 0
                    }
                }
                if(self.PowerStorage>1){
                    if(self.powerSet){
                        self.light.image = UIImage(named: "power1.png")
                        self.powerSet = false
                    }
                    else{
                        self.light.image = UIImage(named: "power2.png")
                        self.powerSet = true
                    }
                }
                self.prX = self.line.center.x
                var Point = self.ball.center
                Point.x -= CGFloat(self.moveX)
                Point.y -= CGFloat(self.moveY)
                self.ball.center = Point
                let ballX:Int = Int(self.ball.center.x)
                let ballY:Int = Int(self.ball.center.y)
                let lineX:Int = Int(self.line.center.x)
                let lineY:Int = Int(self.line.center.y)
                if(ballX < 0){
                    self.ball.center.x = 1
                    self.moveX *= -1
                }
                else if(ballX > self.width){
                    self.ball.center.x = CGFloat(self.width)
                    self.moveX *= -1
                }
                else if(ballY < 0){
                    self.ball.center.y = 1
                    self.moveY *= -1
                }
                else if(ballY > self.height){
                    self.ball.center.y = CGFloat(self.height)
                    self.GameOver()
                }
                else if(abs(ballY - lineY) < 15){
                    if(abs(ballX-lineX) < (self.lineWidth/2)+5){
                        if(self.PowerStorage>2){
                            self.CatchPlayer2.play()
                        }
                        else if(self.PowerStorage>1.3){
                            self.CatchPlayer1.play()
                        }
                        else{
                            self.CatchPlayer0.play()
                        }
                        self.moveX *= self.PowerStorage
                        self.moveY *= self.PowerStorage
                        self.PowerStorage = 1
                        self.light.alpha = 0
                        var angelX = (Double)(abs(ballX-lineX)/50)
                        if(ballX>lineX){
                            if(abs(ballX-lineX)>(self.lineWidth/4)){
                                self.moveX = (abs(self.moveX)+(2*angelX)) * -1
                            }
                            else{
                                self.moveX = (abs(self.moveX)-(2*(1-angelX))) * -1
                            }
                            
                        }
                        else{
                            if(abs(ballX-lineX)>(self.lineWidth/4)){
                                self.moveX = abs(self.moveX)-(2*angelX)
                            }
                            else{
                                self.moveX = abs(self.moveX)+(2*(1-angelX))
                            }
                        }
                        self.moveY *= -1
                    }
                }
                if(self.brickImageView.count>0){
                    for i in 0..<self.brickImageView.count{
                        //print(self.AngelHit(dx: Double(abs(self.brickImageView[i].center.x-self.ball.center.x)), dy: Double(abs(self.brickImageView[i].center.y-self.ball.center.y))))
                        
                        //var x = pow(Double(abs(self.brickImageView[i].center.x-self.ball.center.x),2)
                        var brickx = self.brickImageView[i].center.x
                        var bricky = self.brickImageView[i].center.y
                        var bx:[CGFloat] = [brickx-55,brickx+55,brickx,brickx]
                        var by:[CGFloat] = [bricky,bricky,bricky-15,bricky+15]
                        
                        //print(a)
                        
                        for i in 0..<4{
                            //var dx:Double = Double(bx-self.ball.center.x)
                            //var dy:Double = abs(Double(by-self.ball.center.y))
                            //var a:Double = sqrt((dx*dx) + (dy*dy))
                            //var x:Double = 15 * a / dy
                            
                            
                        }
                        //if(a-x-15 <= 0 && x < 100){
                        //    print("hit!")
                        
                        if(abs(self.brickImageView[i].center.x-self.ball.center.x) < 52 && abs(self.brickImageView[i].center.y-self.ball.center.y) < 27){
                            
                            self.HitPlayer.play()
                            self.score += Int(10*abs(self.moveX*self.moveY))
                            self.showScore.text = String(format: "分數:%d   時間:%d",self.score,self.time)
                            self.brickImageView[i].removeFromSuperview()
                            
                            //self.brickUIView.remove(at: i)
                            self.brickImageView.remove(at: i)
                            self.moveX *= -1+(0.1*self.moveX)
                            self.moveY *= -1+(0.1*self.moveY)
                            if(self.time==0){
                                self.Win()
                            }
                            break
                            //}
                        }
                    }
                }
                else{
                    self.bornBrick()
                }
                
                
            }
        }
    }
    
    
    func startTimer2() {
        self.timer2 = Timer.scheduledTimer(withTimeInterval: 3, repeats: true) { (_) in
            if(self.isPlaying){
                self.bornBrick()
            }
        }
    }
    
    
    func startTimer3() {
        self.timer3 = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { (_) in
            if(self.isPlaying){
                self.time -= 1
                self.showScore.text = String(format: "分數:%d   時間:%d",self.score,self.time)
                if(self.time<=0){
                    self.Win()
                }
            }
        }
    }
    
    
    func AngelWall(dx:Double,dy:Double) -> Double {
        angel = acos(dy/sqrt(pow(dx,2)+pow(dy,2))) * 180 / Double.pi
        return angel
    }
    
    
    func bornBrick() {
        let myImageView = UIImageView(
            frame: CGRect(
                x: 0, y: 0, width: 110, height: 30))
        let imgName = "brick"+String(Int.random(in: 1...9))
        
        myImageView.image = UIImage(named: imgName)
        let newX = Int(arc4random_uniform(UInt32(brickView.frame.width)))
        let newY = Int(arc4random_uniform(UInt32(brickView.frame.height)))
        myImageView.center = CGPoint(
            x: newX,
            y: newY)
        myImageView.backgroundColor = UIColor.green
        brickImageView.append(myImageView)
        brickView.addSubview(myImageView)
        
        //let myUIView = UIView(
        //frame: CGRect(x: 0, y: 0, width: 110, height: 30))
        //myUIView.center = CGPoint(x: newX,y: newY)
        //myUIView.backgroundColor = UIColor.green
        //brickUIView.append(myUIView)
        //brickView.addSubview(myUIView)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.ball.center.x = UIScreen.main.bounds.width/2
        self.ball.center.y = (UIScreen.main.bounds.height*6.5/10)-25
        self.line.center.x = UIScreen.main.bounds.width/2
        self.line.center.y = (UIScreen.main.bounds.height*6.5/10)
        self.winView.center.x = UIScreen.main.bounds.width/2
        self.winView.center.y = self.playView.center.y
        self.winView.isHidden = true
        self.startTimer1()
        self.startTimer2()
        self.startTimer3()
    }
}




